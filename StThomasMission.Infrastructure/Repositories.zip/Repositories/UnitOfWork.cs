﻿using Microsoft.EntityFrameworkCore.Storage;
using StThomasMission.Core.Entities;
using StThomasMission.Core.Interfaces;
using StThomasMission.Infrastructure.Data;
using StThomasMission.Infrastructure.Repositories;

public class UnitOfWork : IUnitOfWork
{
    private readonly StThomasMissionDbContext _dbContext;

    public UnitOfWork(StThomasMissionDbContext dbContext)
    {
        _dbContext = dbContext;
        Students = new StudentRepository(_dbContext);
        Families = new Repository<Family>(_dbContext);
        FamilyMembers = new FamilyMemberRepository(_dbContext);
        Assessments = new Repository<Assessment>(_dbContext);
        GroupActivities = new Repository<GroupActivity>(_dbContext);
        StudentGroupActivities = new StudentGroupActivityRepository(_dbContext); // ✅ correct
        MessageLogs = new Repository<MessageLog>(_dbContext);
        AuditLogs = new Repository<AuditLog>(_dbContext);
        Attendances = new AttendanceRepository(_dbContext);
    }

    public IStudentRepository Students { get; }
    public IRepository<Family> Families { get; }
    public IFamilyMemberRepository FamilyMembers { get; }
    public IAttendanceRepository Attendances { get; }
    public IRepository<Assessment> Assessments { get; }
    public IRepository<GroupActivity> GroupActivities { get; }
    public IStudentGroupActivityRepository StudentGroupActivities { get; } // ✅ correct
    public IRepository<MessageLog> MessageLogs { get; }
    public IRepository<AuditLog> AuditLogs { get; }

    public async Task<IDbContextTransaction> BeginTransactionAsync()
    {
        return await _dbContext.Database.BeginTransactionAsync();
    }

    public async Task CompleteAsync()
    {
        await _dbContext.SaveChangesAsync();
    }

    public void Dispose()
    {
        _dbContext.Dispose();
    }
}
